New fetch env
